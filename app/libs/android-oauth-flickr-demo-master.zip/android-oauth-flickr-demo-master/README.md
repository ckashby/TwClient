android-oauth-flicker-demo
==========================

Android App Using RestClientTemplate for Flickr

![Flickr](http://i.imgur.com/9fkukDU.png)
